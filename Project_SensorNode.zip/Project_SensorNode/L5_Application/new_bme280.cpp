/*
 * new_bme280.cpp
 *
 *  Created on: Nov 25, 2018
 *      Author: halak
 */

#include"new_bme280.hpp"

BME280::BME280()
{

    i2c_p = NULL;
     dig_T1 = 0;
     dig_T2 = 0, dig_T3 = 0;
     dig_P1 = 0;
     dig_P2=0, dig_P3=0, dig_P4=0, dig_P5=0, dig_P6=0, dig_P7=0, dig_P8=0, dig_P9=0;
     dig_H1=0, dig_H3=0;
     dig_H2=0, dig_H4=0, dig_H5=0, dig_H6=0;
        t_fine=0;

}

void BME280::initialize()
{
    i2c.init(100);

    char cmd[18];

    cmd[0] = 0xf2; // ctrl_hum
    cmd[1] = 0x01; // Humidity oversampling x1
    i2c.writeReg(address, cmd[0], cmd[1]);

    cmd[0] = 0xf4; // ctrl_meas
    cmd[1] = 0xAB; // Temparature oversampling x1, Pressure oversampling x1, Normal mode
    i2c.writeReg(address, cmd[0], cmd[1]);

    cmd[0] = 0xf5; // config
    cmd[1] = 0xD0; // Standby 1000ms, Filter off
    i2c.writeReg(address, cmd[0], cmd[1]);

    cmd[0] = 0x88; // read dig_T regs
    //i2c.writeReg(address, cmd[0], cmd[1]);
    uint8_t readadd[6] = {0x88,0x89,0x8A,0X8B,0X8C,0X8D};
    for(int i=0;i<6;i++)
          {
          uint8_t byte = 0;
          i2c.readRegisters(address,readadd[i], &byte, 1);
          cmd[i] = byte;
          }

    dig_T1 = (cmd[1] << 8) | cmd[0];
    dig_T2 = (cmd[3] << 8) | cmd[2];
    dig_T3 = (cmd[5] << 8) | cmd[4];

    //printf(" dig_T1 = %d, dig_T2 = %d, dig_T3 = %d\n",dig_T1, dig_T2, dig_T3);

   // printf("dig_T = 0x%x, 0x%x, 0x%x\n", dig_T1, dig_T2, dig_T3);

    cmd[0] = 0x8E; // read dig_P regs
    //i2c.writeReg(address, cmd[0], cmd[1]);
        uint8_t readadd1[18] = {0X8E,0X8F,0X90,0X91,0X92,0X93,0X94,0X95,0X96,0X97,0X98,0X99,0X9A,0X9B,0X9C,0X9D,0X9E,0X9F};
        for(int i=0;i<18;i++)
              {
              uint8_t byte = 0;
              i2c.readRegisters(address,readadd1[i], &byte, 1);
              cmd[i] = byte;
              }

    dig_P1 = (cmd[ 1] << 8) | cmd[ 0];
    dig_P2 = (cmd[ 3] << 8) | cmd[ 2];
    dig_P3 = (cmd[ 5] << 8) | cmd[ 4];
    dig_P4 = (cmd[ 7] << 8) | cmd[ 6];
    dig_P5 = (cmd[ 9] << 8) | cmd[ 8];
    dig_P6 = (cmd[11] << 8) | cmd[10];
    dig_P7 = (cmd[13] << 8) | cmd[12];
    dig_P8 = (cmd[15] << 8) | cmd[14];
    dig_P9 = (cmd[17] << 8) | cmd[16];

   // printf("dig_P = 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x\n", dig_P1, dig_P2, dig_P3, dig_P4, dig_P5, dig_P6, dig_P7, dig_P8, dig_P9);

    cmd[0] = 0xA1; // read dig_H regs
    //i2c.writeReg(address, cmd[0], cmd[1]);
    i2c.readReg(address, cmd[0]);
     cmd[1] = 0xE1; // read dig_H regs
     //i2c.writeReg(address, cmd[0], cmd[1]);
     uint8_t readadd2[7] = {0XE1,0XE2,0XE3,0XE4,0XE5,0XE6,0XE7};
     for(int i=0;i<7;i++)
                   {
                   uint8_t byte = 0;
                   i2c.readRegisters(address,readadd2[i], &byte, 1);
                   cmd[i+1] = byte;
                   }

    dig_H1 = cmd[0];
    dig_H2 = (cmd[2] << 8) | cmd[1];
    dig_H3 = cmd[3];
    dig_H4 = (cmd[4] << 4) | (cmd[5] & 0x0f);
    dig_H5 = (cmd[6] << 4) | ((cmd[5]>>4) & 0x0f);
    dig_H6 = cmd[7];

    //printf("dig_H = 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x\n", dig_H1, dig_H2, dig_H3, dig_H4, dig_H5, dig_H6);
}

float BME280::getTemperature()
{
    uint32_t temp_raw;
    float tempf;
    char cmd[4];

    cmd[0] = 0xfa; // temp_msb
    //i2c.writeReg(0xec, cmd[0], 0);
    uint8_t readadd[3] = {0xFA,0XFB,0XFC};
    for(int i=0;i<3;i++)
    {
       uint8_t byte = 0;
       i2c.readRegisters(address,readadd[i], &byte, 1);
       cmd[i+1] = byte;
    }

    temp_raw = (cmd[1] << 12) | (cmd[2] << 4) | (cmd[3] >> 4);

    int32_t temp;

    temp =
        (((((temp_raw >> 3) - (dig_T1 << 1))) * dig_T2) >> 11) +
        ((((((temp_raw >> 4) - dig_T1) * ((temp_raw >> 4) - dig_T1)) >> 12) * dig_T3) >> 14);

    t_fine = temp;
    temp = (temp * 5 + 128) >> 8;
    tempf = (float)temp;
    //printf("tempf %f",tempf);
    return (tempf/100.0f);
}

float BME280::getPressure()
{
    uint32_t press_raw;
    float pressf;
    char cmd[4];

    cmd[0] = 0xf7; // press_msb
    ///////i2c.writeReg(0xec, cmd[0], cmd[1]);
    uint8_t readadd[3] = {0xF7,0XF8,0XF9};
    for(int i=0;i<3;i++)
    {
       uint8_t byte = 0;
       i2c.readRegisters(address,readadd[i], &byte, 1);
       cmd[i+1] = byte;
    }

    press_raw = (cmd[1] << 12) | (cmd[2] << 4) | (cmd[3] >> 4);

    int32_t var1, var2;
    uint32_t press;

    var1 = (t_fine >> 1) - 64000;
    var2 = (((var1 >> 2) * (var1 >> 2)) >> 11) * dig_P6;
    var2 = var2 + ((var1 * dig_P5) << 1);
    var2 = (var2 >> 2) + (dig_P4 << 16);
    var1 = (((dig_P3 * (((var1 >> 2)*(var1 >> 2)) >> 13)) >> 3) + ((dig_P2 * var1) >> 1)) >> 18;
    var1 = ((32768 + var1) * dig_P1) >> 15;
    if (var1 == 0) {
        return 0;
    }
    press = (((1048576 - press_raw) - (var2 >> 12))) * 3125;
    if(press < 0x80000000) {
        press = (press << 1) / var1;
    } else {
        press = (press / var1) * 2;
    }
    var1 = ((int32_t)dig_P9 * ((int32_t)(((press >> 3) * (press >> 3)) >> 13))) >> 12;
    var2 = (((int32_t)(press >> 2)) * (int32_t)dig_P8) >> 13;
    press = (press + ((var1 + var2 + dig_P7) >> 4));

    pressf = (float)press;
    return (pressf/1000.0f);
}

float BME280::getHumidity()
{
    uint32_t hum_raw;
    float humf;
    char cmd[4];

    cmd[0] = 0xfd; // hum_msb
   /// i2c.writeReg(0xec, cmd[0], cmd[1]);
    uint8_t readadd[3] = {0xFD,0XFE,0XFF};
    for(int i=0;i<3;i++)
    {
       uint8_t byte = 0;
       i2c.readRegisters(address,readadd[i], &byte, 1);
       cmd[i+1] = byte;
    }

    hum_raw = (cmd[1] << 8) | cmd[2];

    int32_t v_x1;

    v_x1 = t_fine - 76800;
    v_x1 =  (((((hum_raw << 14) -(((int32_t)dig_H4) << 20) - (((int32_t)dig_H5) * v_x1)) +
               ((int32_t)16384)) >> 15) * (((((((v_x1 * (int32_t)dig_H6) >> 10) *
                                            (((v_x1 * ((int32_t)dig_H3)) >> 11) + 32768)) >> 10) + 2097152) *
                                            (int32_t)dig_H2 + 8192) >> 14));
    v_x1 = (v_x1 - (((((v_x1 >> 15) * (v_x1 >> 15)) >> 7) * (int32_t)dig_H1) >> 4));
    v_x1 = (v_x1 < 0 ? 0 : v_x1);
    v_x1 = (v_x1 > 419430400 ? 419430400 : v_x1);

    humf = (float)(v_x1 >> 12);

    return (humf/1024.0f);
}





